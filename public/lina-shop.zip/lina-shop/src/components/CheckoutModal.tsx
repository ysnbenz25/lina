import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, MapPin, Truck } from 'lucide-react';
import { CartItem, Order, TUNISIA_GOVERNORATES } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onOrderConfirmed: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onOrderConfirmed,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [delegation, setDelegation] = useState('');
  const [address, setAddress] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !phone.trim() || !governorate.trim()) return;

    const randDigits = Math.floor(100000 + Math.random() * 900000);
    const trackingCode = `TN-${randDigits}`;

    const fullAddress = [
      delegation.trim() ? `المعتمدية: ${delegation.trim()}` : '',
      address.trim() ? `العنوان: ${address.trim()}` : ''
    ].filter(Boolean).join(' - ');

    const newOrder: Order = {
      id: `ORD-TN-${Date.now()}`,
      trackingNumber: trackingCode,
      customerName: customerName.trim(),
      phone: phone.trim(),
      city: governorate.trim(),
      delegation: delegation.trim(),
      address: fullAddress || address.trim(),
      items: [...cartItems],
      subtotal,
      total: subtotal,
      status: 'processing',
      createdAt: new Date().toISOString().split('T')[0],
    };

    onOrderConfirmed(newOrder);
  };

  return (
    <div
      id="checkout-modal-backdrop"
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <div
        id="checkout-modal"
        className="bg-[#101014] border border-[#d4af37]/40 rounded-2xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl max-h-[92vh] overflow-y-auto text-right animate-in zoom-in-95 duration-200"
      >
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#d4af37] flex items-center justify-center font-bold">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white font-serif">إتمام الطلب وتحديد ولاية التوصيل</h3>
            <p className="text-xs text-[#d4af37]">توصيل سريع لكافة ولايات تونس الـ 24 والدفع عند الاستلام 🇹🇳</p>
          </div>
        </div>

        {/* Order summary bar */}
        <div className="p-3.5 bg-[#08080a] rounded-xl border border-white/5 mb-5 flex items-center justify-between text-xs">
          <span className="text-neutral-400">عدد المنتجات ({cartItems.length}):</span>
          <span className="text-[#d4af37] font-bold font-sans text-sm">
            {subtotal.toLocaleString()} د.ت
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              الاسم واللقب *
            </label>
            <input
              type="text"
              required
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="مثال: أنيس بن مسعود"
              className="w-full px-4 py-2.5 rounded-xl bg-[#08080a] border border-white/10 text-white text-sm focus:border-[#d4af37] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              رقم الهاتف التونسي (8 أرقام) *
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3 text-xs text-neutral-400 font-mono select-none" dir="ltr">
                +216
              </span>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="XX XXX XXX (مثال: 98 123 456)"
                dir="ltr"
                className="w-full pl-14 pr-4 py-2.5 rounded-xl bg-[#08080a] border border-white/10 text-white text-sm focus:border-[#d4af37] focus:outline-none transition-colors text-left font-mono"
              />
            </div>
          </div>

          {/* Governorate Dropdown (All 24 Tunisian Governorates) */}
          <div>
            <label className="block text-xs font-semibold text-[#d4af37] mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>الولاية (إحدى ولايات الجمهورية التونسية الـ 24) *</span>
            </label>
            <select
              required
              value={governorate}
              onChange={(e) => setGovernorate(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#08080a] border border-[#d4af37]/40 text-white text-sm focus:border-[#d4af37] focus:outline-none transition-colors cursor-pointer"
            >
              <option value="" disabled className="bg-[#101014] text-neutral-400">
                -- اختر الولاية من القائمة (24 ولاية) --
              </option>
              {TUNISIA_GOVERNORATES.map((gov) => (
                <option key={gov} value={gov} className="bg-[#101014] text-white">
                  {gov}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              المعتمدية / المنطقة *
            </label>
            <input
              type="text"
              required
              value={delegation}
              onChange={(e) => setDelegation(e.target.value)}
              placeholder="مثال: المرسى، رادس، سوسة جوهرة، قرطاج، الحمامات..."
              className="w-full px-4 py-2.5 rounded-xl bg-[#08080a] border border-white/10 text-white text-sm focus:border-[#d4af37] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              العنوان بالتفصيل (الشارع، رقم العمارة أو المنزل) *
            </label>
            <textarea
              required
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="مثال: نهج ابن خلدون، عمارة الياسمين، الشقة 4..."
              className="w-full px-4 py-2.5 rounded-xl bg-[#08080a] border border-white/10 text-white text-sm focus:border-[#d4af37] focus:outline-none transition-colors"
            />
          </div>

          {/* Delivery & Payment Note */}
          <div className="p-3 bg-[#08080a] rounded-xl border border-white/5 space-y-1.5 text-xs text-neutral-400">
            <div className="flex items-center gap-2 text-[#d4af37]">
              <Truck className="w-4 h-4 shrink-0" />
              <span className="font-bold">التوصيل متوفر لجميع الـ 24 ولاية تونسية</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              الدفع نقداً عند الاستلام (Paiement à la livraison) بعد معاينة العطر، مع تقديم فاتورة رسمية وعيّنتين مجانيتين.
            </p>
          </div>

          <div className="pt-1 flex items-center gap-2 text-xs text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-[#d4af37] shrink-0" />
            <span>بياناتكم مشفرة ومحمية بخصوصية تامة</span>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-gradient-to-r from-[#d4af37] to-[#b89428] hover:from-[#e5ca78] hover:to-[#d4af37] text-[#08080a] font-bold rounded-xl text-sm transition-all shadow-lg shadow-[#d4af37]/20 active:scale-98 mt-2"
          >
            تأكيد الطلب وتوليد كود التتبع الآن (دفع عند الاستلام)
          </button>
        </form>
      </div>
    </div>
  );
};
