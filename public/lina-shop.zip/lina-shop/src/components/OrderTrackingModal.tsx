import React, { useState } from 'react';
import { X, Search, Truck, CheckCircle2, Clock, PackageCheck, AlertCircle } from 'lucide-react';
import { Order } from '../types';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  initialTrackingCode?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  orders,
  initialTrackingCode = '',
}) => {
  const [searchCode, setSearchCode] = useState(initialTrackingCode);
  const [searchedOrder, setSearchedOrder] = useState<Order | null>(() => {
    if (initialTrackingCode) {
      return orders.find((o) => o.trackingNumber.toUpperCase() === initialTrackingCode.toUpperCase()) || null;
    }
    return orders.length > 0 ? orders[0] : null;
  });
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = searchCode.trim().toUpperCase();
    const found = orders.find((o) => o.trackingNumber.toUpperCase() === cleanCode);
    setSearchedOrder(found || null);
    setHasSearched(true);
  };

  const getStepStatus = (orderStatus: Order['status'], stepIndex: number) => {
    const statusMap = { processing: 0, shipped: 1, delivered: 2 };
    const currentIndex = statusMap[orderStatus] ?? 0;
    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'upcoming';
  };

  return (
    <div
      id="tracking-modal-backdrop"
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <div
        id="tracking-modal"
        className="bg-[#101014] border border-[#d4af37]/40 rounded-2xl max-w-xl w-full p-6 sm:p-8 relative shadow-2xl max-h-[92vh] overflow-y-auto text-right animate-in zoom-in-95 duration-200"
      >
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#d4af37] flex items-center justify-center font-bold">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white font-serif">نظام تتبع الشحنات المباشر</h3>
            <p className="text-xs text-neutral-400">تتبع مسار طلبك وموقع الشحنة حتى باب منزلك</p>
          </div>
        </div>

        {/* Search input */}
        <form onSubmit={handleSearch} className="flex gap-2 mb-6">
          <input
            type="text"
            required
            value={searchCode}
            onChange={(e) => setSearchCode(e.target.value)}
            placeholder="أدخل كود التتبع (مثال: TN-784291)"
            dir="ltr"
            className="flex-1 px-4 py-3 rounded-xl bg-[#08080a] border border-white/15 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#d4af37] font-sans uppercase text-left transition-colors"
          />
          <button
            type="submit"
            className="px-6 py-3 bg-[#d4af37] hover:bg-[#e5ca78] text-[#08080a] font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 shrink-0 active:scale-95"
          >
            <Search className="w-4 h-4" />
            <span>بحث وتتبع</span>
          </button>
        </form>

        {/* Result Container */}
        {searchedOrder ? (
          <div className="p-5 bg-[#08080a] rounded-xl border border-[#d4af37]/30 space-y-5">
            {/* Header info */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-[11px] text-neutral-400 block">رقم بوليصة التتبع:</span>
                <span className="text-lg font-bold text-[#d4af37] font-sans">
                  {searchedOrder.trackingNumber}
                </span>
              </div>
              <div className="text-left">
                <span className="text-[11px] text-neutral-400 block">تاريخ التسجيل:</span>
                <span className="text-xs text-white font-sans">{searchedOrder.createdAt}</span>
              </div>
            </div>

            {/* Recipient Details */}
            <div className="p-3.5 bg-[#101014] rounded-lg border border-white/5 text-xs text-neutral-300 space-y-1">
              <p>
                <strong className="text-white">المستلم:</strong> {searchedOrder.customerName} (
                <span dir="ltr">{searchedOrder.phone}</span>)
              </p>
              <p>
                <strong className="text-white">العنوان:</strong> {searchedOrder.city} - {searchedOrder.address}
              </p>
            </div>

            {/* Timeline */}
            <div className="space-y-3 pt-2">
              <h5 className="text-xs font-bold text-white">مسار الشحنة المباشر:</h5>

              <div className="space-y-3">
                {/* Step 1: Processing */}
                {(() => {
                  const status = getStepStatus(searchedOrder.status, 0);
                  return (
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                          status === 'completed' || status === 'current'
                            ? 'bg-[#d4af37] text-[#08080a]'
                            : 'bg-[#1a1a24] text-neutral-500'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h6
                          className={`text-xs font-bold ${
                            status === 'current' ? 'text-[#d4af37] text-sm' : 'text-white'
                          }`}
                        >
                          1. قيد التجهيز في دار لينا للعطور
                        </h6>
                        <p className="text-[11px] text-neutral-400">
                          يتم تجهيز العبوات الفاخرة وإضافة العينات المجانية والتغليف المحكم
                        </p>
                      </div>
                    </div>
                  );
                })()}

                {/* Step 2: Shipped */}
                {(() => {
                  const status = getStepStatus(searchedOrder.status, 1);
                  return (
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                          status === 'completed' || status === 'current'
                            ? 'bg-[#d4af37] text-[#08080a]'
                            : 'bg-[#1a1a24] text-neutral-500'
                        }`}
                      >
                        <Truck className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h6
                          className={`text-xs font-bold ${
                            status === 'current' ? 'text-[#d4af37] text-sm' : status === 'completed' ? 'text-white' : 'text-neutral-500'
                          }`}
                        >
                          2. تم الشحن والتسليم للمندوب
                        </h6>
                        <p className="text-[11px] text-neutral-400">
                          الشحنة في طريقها إلى عنوانك في ولاية {searchedOrder.city}
                        </p>
                      </div>
                    </div>
                  );
                })()}

                {/* Step 3: Delivered */}
                {(() => {
                  const status = getStepStatus(searchedOrder.status, 2);
                  return (
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                          status === 'completed' || status === 'current'
                            ? 'bg-green-500 text-[#08080a]'
                            : 'bg-[#1a1a24] text-neutral-500'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h6
                          className={`text-xs font-bold ${
                            status === 'current' ? 'text-green-400 text-sm' : status === 'completed' ? 'text-white' : 'text-neutral-500'
                          }`}
                        >
                          3. تم التوصيل بنجاح
                        </h6>
                        <p className="text-[11px] text-neutral-400">
                          تم تسليم الطلب للحريف وتأكيد استلام العطور الفاخرة وخلاص الموزع
                        </p>
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>

            {/* Items Summary */}
            <div className="border-t border-white/10 pt-3 space-y-2">
              <span className="text-xs font-bold text-white block">
                محتويات الشحنة ({searchedOrder.items.length}):
              </span>
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {searchedOrder.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex justify-between items-center text-xs text-neutral-300 bg-[#101014] p-2 rounded-lg"
                  >
                    <span>
                      {item.arabicName} × {item.quantity}
                    </span>
                    <span className="text-[#d4af37] font-sans font-bold">
                      {(item.price * item.quantity).toLocaleString()} د.ت
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center text-xs pt-2 border-t border-white/5 font-bold">
                <span className="text-white">الإجمالي النهائي للطلب (شامل التوصيل):</span>
                <span className="text-[#d4af37] font-sans text-sm">
                  {searchedOrder.total.toLocaleString()} د.ت
                </span>
              </div>
            </div>
          </div>
        ) : hasSearched ? (
          <div className="p-8 text-center bg-[#08080a] rounded-xl border border-red-500/30 space-y-2">
            <AlertCircle className="w-8 h-8 text-red-400 mx-auto" />
            <h4 className="text-sm font-bold text-red-400">لم يتم العثور على طلب بهذا الرمز</h4>
            <p className="text-xs text-neutral-400">
              يرجى التأكد من كتابة الرمز بشكل دقيق (مثال: TN-784291)
            </p>
          </div>
        ) : (
          <div className="p-8 text-center text-neutral-500 text-xs bg-[#08080a] rounded-xl border border-white/5">
            أدخل رقم التتبع الخاص بك واضغط على "بحث وتتبع" للاطلاع على حالة الشحنة المباشرة.
          </div>
        )}
      </div>
    </div>
  );
};
